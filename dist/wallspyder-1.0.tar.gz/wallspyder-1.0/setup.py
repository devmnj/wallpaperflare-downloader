from setuptools import setup

setup(
    name='wallspyder',
    version='1.0',
    packages=['wallspyder'],
    url='http://github.com/manojap/wallspyder',
    license='GNU  OPEN SOURCE',
    author='manoj',
    author_email='MANOJAP@OUTLOOK.COM',
    description='Collection Wallpaper downloader selenium browser auutomation'
)
