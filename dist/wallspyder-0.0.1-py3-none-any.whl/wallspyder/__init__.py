print('Thank you for trying wallspyder')

"""
A collection of selenium automation scripts for
searching and downloading wallppaers, stock images
for developing and designing.

originallt wrritten by Manoj A.P 
:print: http://github.com/manojap
"""